// App.js

import React from "react";
import CraneDropdown from "./CraneDropdown";
import LoadDropdown from "./LoadDropdown";
import Title from "./Title";
import NumberInput from "./NumberInput";
import BCCalculator from "./BCCalculator";

 function App() {
  return (
    <div>
     
      <BCCalculator />
    </div>
  );
}

export default App;
 // <CraneDropdown />
 // <LoadDropdown />
 //  <NumberInput />      <Title />
